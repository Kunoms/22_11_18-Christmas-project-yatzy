import random as r

class Terning():



    def terning(self, num):
        terning = []
        for i in range(num):
            terning.append(r.randint(1,6))
            i
        return terning


    def første_kast(self):
        input("Trykk ENTER for å kaste terningene...")
        kast1 = self.terning(5)
        return kast1

    def andre_kast(self, kast1):
        print(kast1)
        print("Hvilke terninger har du lyst til å beholde? [0,4]")
        while True:
            try:
                #beholde_index = input("> ")
                temp = map(int, input("> ").split())
                beholde_index = list(temp)
                break
            except ValueError:
                print("Vær så snill å skriv de terningene du vil beholde i index form \"x x x x x\"")
        beholde_terning = []
        kast2 = self.terning(5 - len(beholde_index))

        for i in beholde_index:
            beholde_terning.append(kast1[i])


        print("Du beholdt ", beholde_terning)
        input("\n Trykk ENTER for å kaste de resterende terningene...\n")
        print("Du kastet ", kast2)
        beholde_terning = beholde_terning + kast2
        print("\nDine terninger er", beholde_terning)
        return beholde_terning

    def tredje_kast(self, kast2):
        print("Hvilke terninger har du lyst til å beholde? [0, 4]")

        while True:
            try:
                temp = map(int, input("> ").split())
                beholde_index = list(temp)                
                break
            except ValueError:
                print("Vær så snill å skriv de terningene du vil beholde i index form \"x x x x x\"")
            
        beholde_terning = []
        kast3 = self.terning(5-len(beholde_index))

        for i in beholde_index:
            beholde_terning.append(kast2[i])
        print("Du beholdt ", beholde_terning)
        input("\nTrykk ENTER for å kaste de resterende terningene...\n")
        beholde_terning= beholde_terning + kast3
        print("\n Dine terninger er", beholde_terning)
        return beholde_terning





        #dice=[]
        #for i in range(5):
        #    dice+=[r.randint(1,6)]
        #    dice = sorted(dice)
        #    dice2 = set(dice)
    #
        #print(dice)
        #print(dice2)
        #return dice
