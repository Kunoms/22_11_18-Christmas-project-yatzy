def digs (terning, num):
    poengsum = 0 
    for i in terning:
        if i == int(num):
            poengsum +=int(num)
    return poengsum

def ett_par(terning):
    poengsum = 0
    for i in terning:
        if terning.count(i) >=2:
            poengsum = sum(terning)
            return poengsum
        else:
            return poengsum

def to_par(terning):
    poengsum = 0
    for i in terning:
        if terning.count(i) >=2 and terning.count(i) >=2:
            poengsum = sum(terning)
            return poengsum
        else:
            return poengsum

def tre_like(terning):
    poengsum = 0 
    for i in terning:
        if terning.count(i) >=3:
            poengsum = sum(terning)
            return poengsum
        else:
            return poengsum
        
def fire_like(terning):
    poengsum = 0
    for i in terning:
        if terning.count(i) >= 4:
            poengsum = sum(terning)
            return poengsum
        else:
            return poengsum

def hus(terning):
    poengsum = 0
    terning = sorted(set(terning))
    if len(terning) == 2:
        poengsum = sum(terning)
        return poengsum
    else:
        return poengsum

def liten_straight(terning):
    poengsum = 0
    terning = str(sorted(terning))
    if "1, 2, 3, 4, 5" in terning:
        poengsum = 15
        return poengsum
    else:
        return poengsum

def stor_straight(terning):
    poengsum = 0
    terning = str(sorted(terning))
    if "2, 3, 4, 5, 6" in terning:
        poengsum = 20
        return poengsum
    else:
        return poengsum

def yatzy(terning):
    poengsum = 0
    count = 1
    for i in range(0, 4):
        if terning[i] == terning[i+1]:
            count +=1
    if count == 5:
        poengsum = 50
        return poengsum
    else:
        return poengsum

def sjanse(terning):
    poengsum = sum(terning)
    return poengsum


#def yahtzee_ting(terning):
#    terning2 = sorted(terning)
#    if len(terning2) == 3 and (terning[0] == terning[1] and terning[1] == terning[2]):
#        return "Tre like"
#    elif len(terning2) == 2 and (terning[0] == terning[1]):
#        return "Ett par"
#    elif len(terning2) == 5 and (terning[0] == terning[1] and terning[1] == terning[2] and terning[2] == terning[3] and terning[3]== terning[4]):
#        return "Yatzy"
#    elif len(terning2) == 5 and ((terning[0] == terning[1] and terning[1] == terning[2] and terning[3] == terning[4]) or (terning[0] == terning[1] and terning[2] == terning[3] and terning[3] == terning[4])):
#        return "Hus"
#    elif len(terning2) == 5 and (terning2 == range(0,6)):
#        return "Liten straight"
#    elif len(terning2) == 5 and ( terning2 == range(1,7)):
#        return "Stor straight"
#    elif len(terning2) == 4 and (terning[0] == terning[1] and terning[1]== terning[2] and terning[2] == terning[3]):
#        return "Fire like"
#    elif len(terning2) == 4 and (terning[0] == terning[1] and terning[2] == terning[3]):
#        return "To par"
#