import random as r
import poengsum
from terning import Terning
from prettytable import PrettyTable

# Poeng liste/Yatzy brett for to eller en personer
# Det er tekst yatzy. Yatzy i terminalen
class Poengsum(object):

    def __init__(self, navn):
        self.navn = navn
        self.card = {"Enere" : None,
            "Toere" : None,
            "Treere" : None,
            "Firere" : None,
            "Femmere" : None,
            "Seksere" : None,
            "Bonus" : None,
            "Ett par" : None,
            "To par" : None,
            "Tre like" : None,
            "Fire like" : None,
            "Hus" : None,
            "Liten straight" : None,
            "Stor straight" : None,
            "Sjanse" : None,
            "Yatzy" : None}
        self.round = 0

# Prettytable lagd spillebrett

    def brett_gen(self):
        pretty_brett = PrettyTable(["Kategori", self.navn])
        pretty_brett.add_row(["Enere", self.card["Enere"]])
        pretty_brett.add_row(["Toere", self.card["Toere"]])
        pretty_brett.add_row(["Treere", self.card["Treere"]])   
        pretty_brett.add_row(["Firere", self.card["Firere"]])
        pretty_brett.add_row(["Femmere", self.card["Femmere"]])
        pretty_brett.add_row(["Seksere", self.card["Seksere"]])
        pretty_brett.add_row(["Bonus", self.card["Bonus"]])
        pretty_brett.add_row(["------------", "-"])
        pretty_brett.add_row(["Ett par", self.card["Ett par"]])
        pretty_brett.add_row(["To par", self.card["To par"]])
        pretty_brett.add_row(["Tre like", self.card["Tre like"]])
        pretty_brett.add_row(["Fire like", self.card["Fire like"]])
        pretty_brett.add_row(["Liten straight", self.card["Liten straight"]])
        pretty_brett.add_row(["Stor straight", self.card["Stor straight"]])
        pretty_brett.add_row(["Hus", self.card["Hus"]])
        pretty_brett.add_row(["Sjanse", self.card["Sjanse"]])
        pretty_brett.add_row(["Yatzy", self.card["Yatzy"]])
        pretty_brett.add_row(["TOTAL POENGSUM", "--"])
        print(pretty_brett)
    
    def addpoeng(self, Kategori, poengsum, terning):
        while True:
            if self.card[Kategori] == None:
                self.card[Kategori] = poengsum
                print("Du fikk %r for %s!\n" % (poengsum, Kategori))
                break
            print("Du har allerede poeng på %s, vær så snill å velge en tom kategori.\n" %  Kategori)
            print(terning)
            self.kat_valg(terning)
            break

    def kat_valg(self, terning):
        while True:
            valg = input("Hvilken kategori vil du prøve å få poeng på?\n>")
            if valg == "enere":
                self.addpoeng("Enere", poengsum.digs(terning, 1), terning)
                self.brett_gen()
                break
            elif valg == "toere":
                self.addpoeng("Toere", poengsum.digs(terning, 2), terning)
                self.brett_gen()
                break
            elif valg == "treere": 
                self.addpoeng("Treere", poengsum.digs(terning, 3), terning)
                self.brett_gen()
                break
            elif valg == "firere":
                self.addpoeng("Firere", poengsum.digs(terning, 4), terning)
                self.brett_gen()
                break
            elif valg == "femmere":
                self.addpoeng("Femmere", poengsum.digs(terning, 5), terning)
                self.brett_gen()
                break
            elif valg == "seksere":
                self.addpoeng("Seksere", poengsum.digs(terning, 6), terning)
                self.brett_gen()
                break
            elif valg == "ett_par":
                self.addpoeng("Ett par", poengsum.ett_par(terning), terning)
                self.brett_gen()
                break
            elif valg == "to_par":
                self.addpoeng("To par", poengsum.to_par(terning),terning)
                self.brett_gen()
                break
            elif valg == "tre_like":
                self.addpoeng("Tre like", poengsum.tre_like(terning), terning)
                self.brett_gen()
                break
            elif valg == "fire_like":
                self.addpoeng("Fire like", poengsum.fire_like(terning), terning)
                self.brett_gen()
                break
            elif valg == "hus":
                self.addpoeng("Hus", poengsum.hus(terning), terning)
                self.brett_gen()
                break
            elif valg == "liten_straight":
                self.addpoeng("Liten straight", poengsum.liten_straight(terning), terning)
                self.brett_gen()
                break
            elif valg == "stor_straight":
                self.addpoeng("Stor straight", poengsum.stor_straight(terning),terning)
                self.brett_gen()
                break
            elif valg == "yatzy":
                self.addpoeng("Yatzy", poengsum.yatzy(terning), terning)
                self.brett_gen()
                break
            elif valg == "sjanse":
                self.addpoeng("Sjanse", poengsum.sjanse(terning), terning)
                self.brett_gen()
                break
            print("Vær så snill å skrive inn en kategori som eksisterer...\n")
    def slutt_spill(self):
        if self.card["Enere"] + self.card["Toere"] + self.card["Treere"] + self.card["Firere"] + self.card["Femmere"] + self.card["Seksere"] >= 63:
            self.card["Bonus"] = 50
            print("Du fikk Bonus som er en ekstra 50 poeng!")
        else:
            self.card["Bonus"] = 0
        Total = sum(self.card.values())
        print("%s, din totale poengsum er: %r" % (self.navn, Total))

def round(spiller):
    print("\nDin tur, %s" % spiller.navn)
    terning = Terning()
    kast1 = terning.første_kast()
    kast2 = terning.andre_kast(kast1)
    kast3 = terning.tredje_kast(kast2)
    spiller.kat_valg(kast3)
    spiller.round += 1

def vinner():
    s1 = sum(spiller1.card.values())
    s2 = sum(spiller2.card.values())
    if s1 > s2:
        print("\n \__(^v^)__/ %s Vant!!!") % spiller1.navn
    elif s2 > s2:
        print("\n\__(^v^)__/ %s Vant!!!") % spiller2.navn
    else:
        print("\nWOW! Det ble helt likt! \__(~V~)__/")

spillerantall = input("Er det en eller to spillere?\n> ")
if spillerantall == 2 or "two" in str(spillerantall.lower()):
    spiller1 = Poengsum(input("Navn på spiller 1?\n> "))
    spiller2 = Poengsum(input("Navn på spiller 2?\n> "))
else:
    spiller1 = Poengsum(input("Navn på spiller\n> "))

while spiller1.round < 14:
    round(spiller1)
    if spiller1.round == 14:
        spiller1.slutt_spill()
    try:
        if spiller2:
            round(spiller2)
        elif spiller2.round == 14:
            spiller2.slutt_spill()
    except NameError:
        pass
while True:
    try:
        vinner()
        break
    except NameError:
        pass
